export default function Page() {
  return(
    <div>
      (이번 사진은 연습입니다.)
    </div>
  )
}