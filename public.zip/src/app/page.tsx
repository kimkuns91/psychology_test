"use client";

import { picturesA, picturesB } from "@/lib/constants";
import { questionAFormState, questionBFormState } from "@/atom";
import { useEffect, useState } from "react";

import AnswerPage from "@/components/AnswerPage";
import ImagePage from "@/components/ImagePage";
import Page00 from "@/components/Page00";
import Page01 from "@/components/Page01";
import { PictureType } from "@/interface";
import { useSetRecoilState } from "recoil";

export default function Home() {
  const [page, setPage] = useState(0);
  const setQuestionAFormState = useSetRecoilState(questionAFormState);
  const setQuestionBFormState = useSetRecoilState(questionBFormState);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === " ") {
        setPage((page) => page + 1);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, []);

  useEffect(() => {
    if (page === 0) {
      // 랜덤으로 섞는 함수
      const shuffleArray = (array: PictureType[]) => {
        return array.sort(() => Math.random() - 0.5);
      };

      // picturesA와 picturesB 섞기
      const shuffledA = shuffleArray(picturesA);
      const shuffledB = shuffleArray(picturesB);

      // 상태가 null일 경우를 처리하여 기본값을 제공
      setQuestionAFormState((prev) => ({
        ...prev,
        picture01: shuffledA[0]?.picture ?? "",
        picture02: shuffledA[1]?.picture ?? "",
        picture03: shuffledA[2]?.picture ?? "",
        picture04: shuffledA[3]?.picture ?? "",
        picture05: shuffledA[4]?.picture ?? "",
        picture06: shuffledA[5]?.picture ?? "",
        picture07: shuffledA[6]?.picture ?? "",
        picture08: shuffledA[7]?.picture ?? "",
        picture09: shuffledA[8]?.picture ?? "",
        picture10: shuffledA[9]?.picture ?? "",
        picture11: shuffledA[10]?.picture ?? "",
        picture12: shuffledA[11]?.picture ?? "",
        picture13: shuffledA[12]?.picture ?? "",
        picture14: shuffledA[13]?.picture ?? "",
        picture15: shuffledA[14]?.picture ?? "",
        picture16: shuffledA[15]?.picture ?? "",
        picture17: shuffledA[16]?.picture ?? "",
        picture18: shuffledA[17]?.picture ?? "",
        picture19: shuffledA[18]?.picture ?? "",
        picture20: shuffledA[19]?.picture ?? "",
        picture21: shuffledA[20]?.picture ?? "",
        picture22: shuffledA[21]?.picture ?? "",
        picture23: shuffledA[22]?.picture ?? "",
        picture24: shuffledA[23]?.picture ?? "",
        picture25: shuffledA[24]?.picture ?? "",
        picture26: shuffledA[25]?.picture ?? "",
        picture27: shuffledA[26]?.picture ?? "",
        picture28: shuffledA[27]?.picture ?? "",
        picture29: shuffledA[28]?.picture ?? "",
        picture30: shuffledA[29]?.picture ?? "",
        // 질문 필드도 기본값을 유지하도록 처리
        question01: prev?.question01 ?? null,
        question02: prev?.question02 ?? null,
        question03: prev?.question03 ?? null,
        question04: prev?.question04 ?? null,
        question05: prev?.question05 ?? null,
        question06: prev?.question06 ?? null,
        question07: prev?.question07 ?? null,
        question08: prev?.question08 ?? null,
        question09: prev?.question09 ?? null,
        question10: prev?.question10 ?? null,
        question11: prev?.question11 ?? null,
        question12: prev?.question12 ?? null,
        question13: prev?.question13 ?? null,
        question14: prev?.question14 ?? null,
        question15: prev?.question15 ?? null,
        question16: prev?.question16 ?? null,
        question17: prev?.question17 ?? null,
        question18: prev?.question18 ?? null,
        question19: prev?.question19 ?? null,
        question20: prev?.question20 ?? null,
        question21: prev?.question21 ?? null,
        question22: prev?.question22 ?? null,
        question23: prev?.question23 ?? null,
        question24: prev?.question24 ?? null,
        question25: prev?.question25 ?? null,
        question26: prev?.question26 ?? null,
        question27: prev?.question27 ?? null,
        question28: prev?.question28 ?? null,
        question29: prev?.question29 ?? null,
        question30: prev?.question30 ?? null,
      }));

      setQuestionBFormState((prev) => ({
        ...prev,
        picture01: shuffledB[0]?.picture ?? "",
        picture02: shuffledB[1]?.picture ?? "",
        picture03: shuffledB[2]?.picture ?? "",
        picture04: shuffledB[3]?.picture ?? "",
        picture05: shuffledB[4]?.picture ?? "",
        picture06: shuffledB[5]?.picture ?? "",
        picture07: shuffledB[6]?.picture ?? "",
        picture08: shuffledB[7]?.picture ?? "",
        picture09: shuffledB[8]?.picture ?? "",
        picture10: shuffledB[9]?.picture ?? "",
        picture11: shuffledB[10]?.picture ?? "",
        picture12: shuffledB[11]?.picture ?? "",
        picture13: shuffledB[12]?.picture ?? "",
        picture14: shuffledB[13]?.picture ?? "",
        picture15: shuffledB[14]?.picture ?? "",
        picture16: shuffledB[15]?.picture ?? "",
        picture17: shuffledB[16]?.picture ?? "",
        picture18: shuffledB[17]?.picture ?? "",
        picture19: shuffledB[18]?.picture ?? "",
        picture20: shuffledB[19]?.picture ?? "",
        picture21: shuffledB[20]?.picture ?? "",
        picture22: shuffledB[21]?.picture ?? "",
        picture23: shuffledB[22]?.picture ?? "",
        picture24: shuffledB[23]?.picture ?? "",
        picture25: shuffledB[24]?.picture ?? "",
        picture26: shuffledB[25]?.picture ?? "",
        picture27: shuffledB[26]?.picture ?? "",
        picture28: shuffledB[27]?.picture ?? "",
        picture29: shuffledB[28]?.picture ?? "",
        picture30: shuffledB[29]?.picture ?? "",
        // 질문 필드도 기본값을 유지하도록 처리
        question01: prev?.question01 ?? null,
        question02: prev?.question02 ?? null,
        question03: prev?.question03 ?? null,
        question04: prev?.question04 ?? null,
        question05: prev?.question05 ?? null,
        question06: prev?.question06 ?? null,
        question07: prev?.question07 ?? null,
        question08: prev?.question08 ?? null,
        question09: prev?.question09 ?? null,
        question10: prev?.question10 ?? null,
        question11: prev?.question11 ?? null,
        question12: prev?.question12 ?? null,
        question13: prev?.question13 ?? null,
        question14: prev?.question14 ?? null,
        question15: prev?.question15 ?? null,
        question16: prev?.question16 ?? null,
        question17: prev?.question17 ?? null,
        question18: prev?.question18 ?? null,
        question19: prev?.question19 ?? null,
        question20: prev?.question20 ?? null,
        question21: prev?.question21 ?? null,
        question22: prev?.question22 ?? null,
        question23: prev?.question23 ?? null,
        question24: prev?.question24 ?? null,
        question25: prev?.question25 ?? null,
        question26: prev?.question26 ?? null,
        question27: prev?.question27 ?? null,
        question28: prev?.question28 ?? null,
        question29: prev?.question29 ?? null,
        question30: prev?.question30 ?? null,
      }));
    }
  }, [page, setQuestionAFormState, setQuestionBFormState]);
  
  if (page === 0) return <Page00 />;

  if (page === 1) return <Page01 />;

  if (page === 2) return <ImagePage />;

  if (page === 3) return <AnswerPage />;

  if (page === 4) return <ImagePage />;

  if (page === 5) return <AnswerPage />;

  if (page === 6) return <ImagePage />;

  if (page === 7) return <AnswerPage />;
}
