const Page00: React.FC = () => {
  return (
    <>
      <h1 className="text-3xl">준비가 되면 스페이스 바를 눌러주세요.</h1>
    </>
  );
};

export default Page00;
