const Page02: React.FC = () => {
  return (
    <>
      <h1 className="text-3xl"></h1>
    </>
  );
};

export default Page02;
