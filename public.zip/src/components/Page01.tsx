const Page01: React.FC = () => {
  return (
    <>
      <h1 className="text-3xl">이번 사진은 연습입니다.</h1>
    </>
  );
};

export default Page01;
