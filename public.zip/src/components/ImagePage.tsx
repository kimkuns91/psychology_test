import Image from "next/image";

interface ImagePageProps {
  image?: string;
}

const ImagePage: React.FC<ImagePageProps> = ({ image }) => {
  return (
    <>
      <Image
        src={image || "/images/noPoster.webp"}
        width={1000}
        height={1000}
        alt="pic"
      />
    </>
  );
};

export default ImagePage;
