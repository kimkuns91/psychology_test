import { useEffect, useState } from "react";

import ImagePage from "./ImagePage"; // 이미지 보여주는 컴포넌트
import { questionAFormState } from "@/atom"; // 질문 상태 관리용 Atom
import { useRecoilState } from "recoil";

const QuestionPage: React.FC = () => {
  const [status, setStatus] = useState<"picture" | "question">("picture"); // 상태 관리
  const [currentIndex, setCurrentIndex] = useState(0); // 현재 보여주는 사진 인덱스
  const [questionsA, setQuestionsA] = useRecoilState(questionAFormState); // 질문 상태

  const pictures = [
    questionsA?.picture01,
    questionsA?.picture02,
    questionsA?.picture03,
    // ... 필요한 모든 사진들을 넣음
  ];

  useEffect(() => {
    // 10초간 사진을 보여주고 질문으로 전환
    const timer = setTimeout(() => {
      setStatus("question");
    }, 10000); // 10초 후에 질문 상태로 전환

    return () => clearTimeout(timer); // 컴포넌트 언마운트 시 타이머 클리어
  }, [currentIndex]);

  const handleAnswerSubmit = (answer: string) => {
    // 답변 저장 및 다음 사진으로 넘어가기
    const updatedQuestions = { ...questionsA, [`question0${currentIndex + 1}`]: answer };
    setQuestionsA(updatedQuestions);
    
    // 다음 사진으로 넘기고 다시 사진을 보여주는 상태로 변경
    setCurrentIndex((prevIndex) => prevIndex + 1);
    setStatus("picture");
  };

  if (currentIndex >= pictures.length) {
    return <h1>모든 질문이 완료되었습니다.</h1>; // 모든 사진을 다 본 경우
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen">
      {status === "picture" ? (
        <ImagePage image={pictures[currentIndex] || "/images/noPoster.webp"} />
      ) : (
        <div>
          <h1 className="text-3xl">이번 사진은 연습입니다. 질문에 답해주세요.</h1>
          <input
            type="text"
            placeholder="답변을 입력하세요"
            className="border p-2 mt-4"
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                handleAnswerSubmit(e.currentTarget.value); // 엔터 키로 답변 제출
                e.currentTarget.value = ""; // 입력 필드 초기화
              }
            }}
          />
        </div>
      )}
    </div>
  );
};

export default QuestionPage;
