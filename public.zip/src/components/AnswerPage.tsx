import { useState } from "react";

const AnswerPage: React.FC = () => {
  const [selectedStressLevel, setSelectedStressLevel] = useState<number | null>(
    null
  );

  const stressLevels = [
    { id: 1, label: "1. 전혀 스트레스 받지 않음" },
    { id: 2, label: "2. 스트레스를 받지 않음" },
    { id: 3, label: "3. 보통" },
    { id: 4, label: "4. 약간 스트레스 받음" },
    { id: 5, label: "5. 매우 스트레스 받음" },
  ];

  const handleClick = (id: number) => {
    setSelectedStressLevel(id);
    console.log(`Selected Stress Level: ${id}`);
  };

  return (
    <div className="flex flex-col items-start p-4 space-y-4">
      <h1 className="text-xl font-bold mb-4">스트레스 수준을 선택하세요</h1>
      {stressLevels.map((level) => (
        <button
          key={level.id}
          onClick={() => handleClick(level.id)}
          className={`px-4 py-2 rounded-lg text-left w-full 
          ${
            selectedStressLevel === level.id
              ? "bg-blue-500 text-white"
              : "bg-gray-200 text-gray-800"
          }
          hover:bg-blue-400 hover:text-white transition-all duration-200`}
        >
          {level.label}
        </button>
      ))}
    </div>
  );
};

export default AnswerPage;
