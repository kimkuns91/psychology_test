export const question = [
  { id: 1, label: "1. 전혀 스트레스 받지 않음" },
  { id: 2, label: "2. 스트레스를 받지 않음" },
  { id: 3, label: "3. 보통" },
  { id: 4, label: "4. 약간 스트레스 받음" },
  { id: 5, label: "5. 매우 스트레스 받음" },
];
