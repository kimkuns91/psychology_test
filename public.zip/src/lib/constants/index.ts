import { picturesA, picturesB } from "./pictures";

import { question } from "./question";

export { picturesA, picturesB, question };
