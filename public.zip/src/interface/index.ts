export interface QuestionFormType {
  picture01: string | null;
  picture02: string | null;
  picture03: string | null;
  picture04: string | null;
  picture05: string | null;
  picture06: string | null;
  picture07: string | null;
  picture08: string | null;
  picture09: string | null;
  picture10: string | null;
  picture11: string | null;
  picture12: string | null;
  picture13: string | null;
  picture14: string | null;
  picture15: string | null;
  picture16: string | null;
  picture17: string | null;
  picture18: string | null;
  picture19: string | null;
  picture20: string | null;
  picture21: string | null;
  picture22: string | null;
  picture23: string | null;
  picture24: string | null;
  picture25: string | null;
  picture26: string | null;
  picture27: string | null;
  picture28: string | null;
  picture29: string | null;
  picture30: string | null;

  question01: number | null;
  question02: number | null;
  question03: number | null;
  question04: number | null;
  question05: number | null;
  question06: number | null;
  question07: number | null;
  question08: number | null;
  question09: number | null;
  question10: number | null;
  question11: number | null;
  question12: number | null;
  question13: number | null;
  question14: number | null;
  question15: number | null;
  question16: number | null;
  question17: number | null;
  question18: number | null;
  question19: number | null;
  question20: number | null;
  question21: number | null;
  question22: number | null;
  question23: number | null;
  question24: number | null;
  question25: number | null;
  question26: number | null;
  question27: number | null;
  question28: number | null;
  question29: number | null;
  question30: number | null;
}

export interface PictureType {
  id: number;
  picture: string;
}